﻿using System;
public class Cuyan
{
    int numero;
    string cadena;
    int extra;
    public static void Main()
    {
        Cuyan objetoCuyan2;
        System.Console.WriteLine("*---------MENU---------*");
        System.Console.WriteLine("\nIngrese la opcion segun sea su necesidad");
        System.Console.WriteLine("\n1.Asignacion de valores\n2.Mostrar valores");
        char option = char.Parse(Console.ReadLine());
        switch (option)
        {
            case '1':
            {
                IngresarValores();
                break;
            }
            case '2':
            {
                objetoCuyan2.show();
                break;
            }
            default:
            {
                System.Console.WriteLine("Valor ingresado no valido!");
                break;
            }
        }
    }
    Cuyan(int numero, string cadena, int extra)
    {
        this.numero = numero;
        this.cadena = cadena;
        this.extra = extra;
    }
    void show()
    {
        Console.WriteLine(this.numero);
        Console.WriteLine(this.cadena);
    }
    static void IngresarValores(){
        Console.WriteLine("Ingrese el primer numero");
        int numero1 = int.Parse(Console.ReadLine());
        System.Console.WriteLine("Ingrese un texto");
        string cadena = Console.ReadLine();
        Console.WriteLine("Ingrese el primer numero");
        int numero2 = int.Parse(Console.ReadLine());

        Cuyan objetoCuyan = new Cuyan(numero1, cadena,  numero2);
    }
}