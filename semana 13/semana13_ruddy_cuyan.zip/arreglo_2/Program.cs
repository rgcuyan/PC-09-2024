﻿class Program
{
    public static void Main(string[] args){


        string[,] persona = new string[4, 4];

        for (int i = 0; i < persona.GetLength(0); i++)
        {
            System.Console.WriteLine(persona.GetLength(i));
            System.Console.WriteLine("Ingrese los datos en el siguiente orden\n1.Nombre\n2.Apellido\n3.Edad\n4.telefono");
            System.Console.WriteLine("");
            for (int j = 0; j < persona.GetLength(1); j++)
            {
                persona[i,j] = Console.ReadLine();
            }
        }


    }
}