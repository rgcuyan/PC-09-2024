﻿using System;

namespace Semana14
{
    class Program
    {
        
            int n = 0;
            int total = 0;
            int promedio = 0;
            bool salir = true;
            int[] numeros = new int[12];
            string result = String.Join(",", numeros);
            string[] numText = result.Split(',');
            

        static void Main(string[] args)
        {


            Console.WriteLine("Ingrese 12 números enteros");

            for (int i = 0; i < numeros.Length; i++)
            {
                n = Int32.Parse(Console.ReadLine());
                numeros[i] = n;
            }

            do
            {
                Console.WriteLine("Ingrese la opción que desee realizar");
                Console.WriteLine("1. Sume los números ingresados");
                Console.WriteLine("2. Promedio de los números ingresados");
                Console.WriteLine("3. Ordene de mayor a menor");
                Console.WriteLine("4. Ordene de menor a mayor");
                Console.WriteLine("5. Cambie el tamaño del arreglo dos posiciones más");
                Console.WriteLine("6. Utilizar un split()");
                Console.WriteLine("7. Salir");

                Char opcion = Console.ReadLine().ToLower()[0];

                switch (opcion)
                {
                    case '1':
                        {
                            for (int i = 0; i < numeros.Length; i++)
                            {
                                total = total + numeros[i];
                            }
                            System.Console.WriteLine($"La suma de los digitos es: {total}");
                            break;
                        }
                    case '2':
                        {
                            for (int i = 0; i < numeros.Length; i++)
                            {
                                total = total + numeros[i];
                            }
                            promedio = total / numeros.Length;

                            System.Console.WriteLine($"El promedio de los digitos es: {promedio}");
                            break;
                        }
                    case '3':
                        {
                            Array.Sort(numeros);
                            foreach (int item in numeros)
                            {
                                System.Console.WriteLine($"{item}");
                            }
                            break;
                        }
                    case '4':
                        {
                            Array.Reverse(numeros);
                            foreach (int item in numeros)
                            {
                                System.Console.WriteLine($"{item}");
                            }
                            break;
                        }
                    case '5':
                        {
                            Array.Resize(ref numeros, 14);
                            System.Console.WriteLine($"La longitud del array es: {numeros.Length}");
                            System.Console.WriteLine("\nIngrese los ultimos 2 digitos");
                            for (int i = 12; i < numeros.Length; i++)
                            {
                                n = Int32.Parse(Console.ReadLine());
                                numeros[i] = n;
                            }
                            break;
                        }
                    case '6':
                        {
                            for (int i = 0; i < numeros.Length; i++)
                            {
                               numText[i] = Convert.ToString(numeros[i]);
                            }
                            foreach (string item in numText)
                            {
                                System.Console.WriteLine(item);
                            }
                            break;
                        }
                }
            } while (salir);
        }

        //Metodos
        



    }
}