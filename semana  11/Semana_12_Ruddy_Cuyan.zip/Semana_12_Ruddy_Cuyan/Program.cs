﻿class Program
{
    //Metodo principal
    static void Main(string[] args)
    {
        menu();
    }

    static void menu()
    {
        Console.WriteLine("Semana 12");
        Console.WriteLine(" a) Multiplicación");
        Console.WriteLine(" b) suma");
        Console.WriteLine(" c) Resta ");

        char opcion = Console.ReadLine().ToLower()[0];
        switch (opcion)
        {
            case 'a':
                Console.WriteLine("Ingrese un número para multiplicar");
                int a = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Ingrese un número para multiplicar");
                int b = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("El resultado es :" + Multiplicacion(a, b));
                Console.ReadKey();

                break;
            case 'b':
                Console.WriteLine("Ingrese un número para sumar");
                int asuma = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Ingrese un número para sumar");
                int bsuma = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("El resultado es :" + Suma(asuma, bsuma));
                Console.ReadKey();

                break;
            case 'c':
                Console.WriteLine("Ingrese el número a restar");
                int aresta = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Ingrese un número para restar");
                int bresta = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("El resultado es :" + Resta(aresta, bresta));
                Console.ReadKey();

                break;
            default:
                Console.WriteLine("La opción seleccionada no es válida.");
                break;
        }
    }

    //envio de parámetros
    public static int Multiplicacion(int a, int b)
    {
        int resultado = 0;
        resultado = a * b;
        return resultado;
    }

    public static int Suma(int a, int b){
        int resultado;
        resultado = a + b;
        return resultado;
    }
    public static int Resta(int a, int b){
        int resultado;
        resultado = a - b;
        return resultado;
    }
}