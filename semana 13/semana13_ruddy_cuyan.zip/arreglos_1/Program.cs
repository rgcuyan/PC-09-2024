﻿class Program
{
    public static void Main(string[] args)
    {

        int[] numeros = new int[8];

        for (int i = 0; i < numeros.Length; i++)
        {
            System.Console.WriteLine("Ingrese su digito");
            int variable = Int32.Parse(Console.ReadLine());

            numeros[i] = variable;
        }

        System.Console.WriteLine("Los digitos ingresados son:");
        foreach (int item in numeros)
            System.Console.WriteLine(item);
        {

            int total = 0;
            System.Console.WriteLine("La suma de los datos es:");
            for (int i = 0; i < numeros.Length; i++)
            {
                total = total + numeros[i];
            }

            System.Console.WriteLine($"Suma: {total}");

            int promedio = total / numeros.Length;
            System.Console.WriteLine($"Promedio: {promedio}");
        }
    }
}