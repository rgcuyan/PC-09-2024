﻿//ENTRADAS
string nombre;
int edad;

//PROCESO
Console.WriteLine("Ingrese su nombre");
nombre = Console.ReadLine();
Console.WriteLine("Ingrese su edad en años");
edad = Int32.Parse(Console.ReadLine());

if (edad>0 && edad<=5)
{
    Console.WriteLine($"{nombre} de {edad} años usted se encuentra en la Primera Infancia segun el ciclo de la vida");
}else if (edad>=6 && edad<=11)
{
    Console.WriteLine($"{nombre} de {edad} años usted se encuentra en la Infancia segun el ciclo de la vida");
}else if (edad>=12 && edad<=18)
{
    Console.WriteLine($"{nombre} de {edad} años usted se encuentra en la Adolescencia segun el ciclo de la vida");
}else if (edad>=19 && edad<=25)
{
    Console.WriteLine($"{nombre} de {edad} años usted se encuentra en la Juventud segun el ciclo de la vida");
}else if (edad>=26 && edad<=59)
{
    Console.WriteLine($"{nombre} de {edad} años usted se encuentra en la Adultez segun el ciclo de la vida");
}else {
    Console.WriteLine($"{nombre} de {edad} años usted se encuentra en Persona Mayor segun el ciclo de la vida");
}

Console.ReadKey();